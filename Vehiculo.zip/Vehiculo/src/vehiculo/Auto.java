
package vehiculo;
class Auto extends Vehiculo {
    private String tipoCarroceria;

    // Constructor
    public Auto(String marca, String modelo, String color, String numeroSerie, String tipoCarroceria) {
        super(marca, modelo, color, numeroSerie);
        this.tipoCarroceria = tipoCarroceria;
    }

    // Getter 
    public String getTipoCarroceria() {
        return tipoCarroceria;
    }

    // Metodo Auto
    public void conducir() {
        System.out.println("Conduciendo el auto.");
    }
}