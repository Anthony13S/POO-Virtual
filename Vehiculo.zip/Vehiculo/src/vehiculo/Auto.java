
package vehiculo;

class Auto extends Vehiculo {
     String tipoCarroceria;

    // Constructor
    public Auto(String marca, String modelo, String color, String numeroSerie, String tipoCarroceria) {
        super(marca, modelo, color, numeroSerie);
        this.tipoCarroceria = tipoCarroceria;
    }
    }