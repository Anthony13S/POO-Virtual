package vehiculo;

class Moto extends Vehiculo {
    private String tipoMoto;

    // Constructor
    public Moto(String marca, String modelo, String color, String numeroSerie, String tipoMoto) {
        super(marca, modelo, color, numeroSerie);
        this.tipoMoto = tipoMoto;
    }

    // Getter 
    public String getTipoMoto() {
        return tipoMoto;
    }

    // Metodo Moto
    public void arrancar() {
        System.out.println("Arrancando la moto.");
    }
}