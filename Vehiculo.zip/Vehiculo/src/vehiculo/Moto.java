package vehiculo;

class Moto extends Vehiculo {
    String tipoMoto;

    // Constructor
    public Moto(String marca, String modelo, String color, String numeroSerie, String tipoMoto) {
        super(marca, modelo, color, numeroSerie);
        this.tipoMoto = tipoMoto;
    }
}