
package vehiculo;

    abstract class Vehiculo {
     String marca;
     String modelo;
     String color;
    private String numeroSerie;

    // Constructor
    public Vehiculo(String marca, String modelo, String color, String numeroSerie) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.numeroSerie = numeroSerie;
    }

    // Getters 
    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public String getColor() {
        return color;
    }

    public String getNumeroSerie() {
        return numeroSerie;
    }
}






   

