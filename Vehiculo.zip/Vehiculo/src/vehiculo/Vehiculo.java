
package vehiculo;
abstract class Vehiculo {
    protected String marca;
    protected String modelo;
    protected String color;
    private final String numeroSerie; 

    // Constructor
    public Vehiculo(String marca, String modelo, String color, String numeroSerie) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.numeroSerie = numeroSerie;
    }
    public String getNumeroSerie() {
        return numeroSerie;
    }

}








    
    
    


   

